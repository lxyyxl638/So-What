<html>
<head>
	<title>person_center</title>
</head>

<frameset cols = "25%,50%,25%">
   <frame src = "person/person_center_menu"></frame>
   <frame src = "person/profile" name = "right"></frame>
</frameset>
</html>