<html>
<head>
  <title><?php echo $title ?> - CodeIgniter 2 Tutorial</title>
</head>
<body>
  <h1>CodeIgniter 2 Tutorial</h1>