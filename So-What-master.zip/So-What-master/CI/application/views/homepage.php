<html>
<head>
<title>homepage</title>
</head>
<h1>选择你感兴趣的话题</h1>
<?php echo anchor('q2a/home','毕业季')?><br>
<?php echo anchor('person','个人中心')?>
</html>