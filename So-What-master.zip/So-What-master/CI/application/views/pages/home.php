﻿<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
你好
</head>
</html>