<meta content="text/html; charset=utf-8" http-equiv="Content-Type">	
<html>
<title>show the profile</title>
<body>
	<?php echo $this->table->generate($profile) ?>
</body>
</html>