<html>

<body>

<p>
<img src= <?php echo base_url("uploads/123_thumb.jpg") ?> />
</p>

</body>
</html>
