<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<html>
<head>
<title>错误处理</title>
</head>
<?php echo $error ?>
<p><?php echo anchor('q2a/home',"返回")?></p>
</html>