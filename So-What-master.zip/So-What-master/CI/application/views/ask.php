<html>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">	

<?php echo form_open("q2a/ask_submit") ?>

<h1>提问概述</h1>
<input type = "text" name = "title" size = "50">
<h1>详细内容</h1>
<textarea type = "text" name = "text"  cols = "100" rows = "10"></textarea>
<div><input type="submit" value="提交" /></div>
</html>