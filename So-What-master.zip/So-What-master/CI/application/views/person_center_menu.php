<!DOCTYPE html>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">	
<html>
<head>
	<title>用户管理</title>
</head>
<h2>用户管理</h2>
<a href = "http://localhost/index.php/person/profile" target = "right">个人信息</a><br>
<a href = "http://localhost/index.php/person/change_password" target = "right">修改密码</a><br>
<a href = "http://localhost/index.php/person/myquestions" target = "right">我的提问</a><br>
<a href = "http://localhost/index.php/person/myanswers" target = "right">我的回答</a><br>
<a href = "http://localhost/index.php/person/login_off"  target = "_parent" >退出登录</a><br>
<a href = "http://localhost/index.php/form"  target = "_parent" >返回</a><br>
</html>