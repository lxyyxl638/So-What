<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<html>
<head>
<title>我的注册</title>
</head>
<body>

<h3>注册成功啦！</h3>

<p><?php echo anchor('form', '登陆'); ?></p>

</body>
</html>