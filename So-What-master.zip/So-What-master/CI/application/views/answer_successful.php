﻿<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<html>
<head>
   回答成功
 <p> <?php echo anchor('q2a/home','返回') ?></p>
</head>
</html>